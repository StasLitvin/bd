site_url = '127.0.0.1:5000'
host = "localhost"
user = "admin"
password = "admin"
db_name = "bd"
# папка для сохранения загруженных файлов
UPLOAD_FOLDER = 'static/dok/'
# расширения файлов, которые разрешено загружать
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'docx', 'jpeg'}
