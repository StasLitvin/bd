import mysql.connector
from config import host, user, password, db_name


def data_con():
    return mysql.connector.connect(
        host=host,
        port=3360,
        user=user,
        password=password,
        database=db_name
    )


def residents():
    connection = data_con()
    cursor = connection.cursor()
    quary = '''SELECT * FROM residents'''
    cursor.execute(quary)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return result


def residents_search(search):
    connection = data_con()
    search = search.lower()
    cursor = connection.cursor()
    quary = '''SELECT * FROM bd.residents'''
    cursor.execute(quary)
    result = cursor.fetchall()
    res = [i for i in result if
           (search in i[1].lower()) or (search in i[2].lower()) or (search in i[3].lower()) or (
                   search in i[4].lower()) or (search in i[5].lower()) or (search.lower() in (i[2]+" "+i[3]+" "+i[4]).lower())]
    connection.commit()
    cursor.close()
    connection.close()
    return res


def residents_upset(s):
    connection = data_con()
    cursor = connection.cursor()
    for i in s:
        quary = f'''UPDATE residents SET surname=%s,name=%s,fatherland=%s,phone=%s,elder=%s WHERE id={i} '''
        if len(s[i]) == 5:
            cursor.execute(quary, s[i])
        else:
            cursor.execute(quary, s[i] + [0])
    connection.commit()
    cursor.close()
    connection.close()


def residents_input(f):
    connection = data_con()
    cursor = connection.cursor()
    quary = '''INSERT INTO residents (surname,name,fatherland,phone,groupp,floor,date_birth,elder) VALUE (%s,%s,%s,%s,%s,%s,%s,%s)'''
    cursor.execute(quary, f)
    connection.commit()
    cursor.close()
    connection.close()


def residents_selctor():
    connection = data_con()
    cursor = connection.cursor()
    quary = '''SELECT id,surname,name,fatherland FROM residents WHERE (SELECT COUNT(*) FROM contracts WHERE id_rez=residents.id)<=0'''
    cursor.execute(quary)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return result


print(residents_selctor())


def rooms_selctor():
    connection = data_con()
    cursor = connection.cursor()
    quary = '''SELECT id,floor,block,room FROM rooms WHERE (SELECT COUNT(*) FROM room_cont WHERE id=rooms.id)<rooms.max_res'''
    cursor.execute(quary)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return result


def equipments_selctor():
    connection = data_con()
    cursor = connection.cursor()
    quary = '''SELECT id,name FROM equipments'''
    cursor.execute(quary)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return result


def contract_input(f):
    connection = data_con()
    cursor = connection.cursor()
    quary = '''INSERT INTO contracts (id_rez,contract,file,date,noactive) VALUE (%s,%s,%s,%s,%s)'''
    cursor.execute(quary, f)
    connection.commit()
    cursor.close()
    connection.close()


def contract_search(id):
    connection = data_con()
    cursor = connection.cursor()
    quary = f'''SELECT id FROM contracts WHERE id_rez={id}'''
    cursor.execute(quary)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return result


def contract_room_input(f):
    connection = data_con()
    cursor = connection.cursor()
    quary = '''INSERT INTO room_cont (id_con,id_room,date,prov) VALUE (%s,%s,%s,%s)'''
    cursor.execute(quary, f)
    connection.commit()
    cursor.close()
    connection.close()


def contract_equipment_input(f):
    connection = data_con()
    cursor = connection.cursor()
    quary = '''INSERT INTO equipment_cont (id_con,id_equ,date,prov) VALUE (%s,%s,%s,%s)'''
    cursor.execute(quary, f)
    connection.commit()
    cursor.close()
    connection.close()


def contracts():
    connection = data_con()
    cursor = connection.cursor()
    quary = f'''SELECT room_cont.id,contracts.contract,contracts.file,rooms.floor,rooms.block,rooms.room,contracts.date,room_cont.prov,room_cont.id_room 
    FROM contracts,rooms,room_cont 
    WHERE contracts.id=room_cont.id_con AND room_cont.id_room=rooms.id'''

    cursor.execute(quary)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return result

def contracts_search(search):
    connection = data_con()
    search = search.lower()
    cursor = connection.cursor()
    quary = f'''SELECT room_cont.id,contracts.contract,contracts.file,rooms.floor,rooms.block,rooms.room,contracts.date,room_cont.prov
        FROM contracts,rooms,room_cont 
        WHERE contracts.id=room_cont.id_con AND room_cont.id_room=rooms.id'''
    cursor.execute(quary)
    result = cursor.fetchall()
    res = [i for i in result if
           (search in i[1].lower()) or (search in (str(i[3])+str(i[4])+i[5]).lower())]
    connection.commit()
    cursor.close()
    connection.close()
    return res
def room_upset(s):
    connection = data_con()
    cursor = connection.cursor()
    for i in s:
        quary = f'''UPDATE room_cont SET prov={s[i]} WHERE id={i} '''
        cursor.execute(quary)
    connection.commit()
    cursor.close()
    connection.close()
def equipment():
    connection = data_con()
    cursor = connection.cursor()
    quary = f'''SELECT equipment_cont.id,contracts.contract,contracts.file,equipments.name,contracts.date,equipment_cont.prov
    FROM contracts,equipments,equipment_cont 
    WHERE contracts.id=equipment_cont.id_con AND equipment_cont.id_equ=equipments.id'''

    cursor.execute(quary)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return result
def equipment_search(search):
    connection = data_con()
    search = search.lower()
    cursor = connection.cursor()
    quary = f'''SELECT equipment_cont.id,contracts.contract,contracts.file,equipments.name,contracts.date,equipment_cont.prov,equipment_cont.id_equ 
       FROM contracts,equipments,equipment_cont 
       WHERE contracts.id=equipment_cont.id_con AND equipment_cont.id_equ=equipments.id'''
    cursor.execute(quary)
    result = cursor.fetchall()
    res = [i for i in result if
           (search in i[1].lower()) or (search in i[3].lower())]
    connection.commit()
    cursor.close()
    connection.close()
    return res
def equipment_upset(s):
    connection = data_con()
    cursor = connection.cursor()
    for i in s:
        quary = f'''UPDATE equipment_cont SET prov={s[i]} WHERE id={i} '''
        cursor.execute(quary)
    connection.commit()
    cursor.close()
    connection.close()
def type_reference():
    connection = data_con()
    cursor = connection.cursor()
    quary = f'''SELECT id,name FROM type_reference'''
    cursor.execute(quary)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return result
def reference_input(f):
    connection = data_con()
    cursor = connection.cursor()
    quary = '''INSERT INTO reference (id_res,id_type,file,date) VALUE (%s,%s,%s,%s)'''
    cursor.execute(quary, f)
    connection.commit()
    cursor.close()
    connection.close()
def reference():
    connection = data_con()
    cursor = connection.cursor()
    quary = f'''SELECT reference.id,reference.file,residents.surname,residents.name,residents.fatherland,type_reference.name,reference.date
        FROM reference,residents,type_reference 
        WHERE residents.id=reference.id_res AND reference.id_type=type_reference.id'''
    cursor.execute(quary)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return result
def disciplinary_input(f):
    connection = data_con()
    cursor = connection.cursor()
    quary = '''INSERT INTO disciplinary (id_rez,reason,date) VALUE (%s,%s,%s)'''
    cursor.execute(quary, f)
    connection.commit()
    cursor.close()
    connection.close()
def disciplinary():
    connection = data_con()
    cursor = connection.cursor()
    quary = f'''SELECT disciplinary.id,residents.surname,residents.name,residents.fatherland,disciplinary.reason,disciplinary.date
        FROM disciplinary,residents
        WHERE residents.id=disciplinary.id_rez'''
    cursor.execute(quary)
    result = cursor.fetchall()
    connection.commit()
    cursor.close()
    connection.close()
    return result
def disciplinary_search(search):
    connection = data_con()
    cursor = connection.cursor()
    search = search.lower()
    quary = f'''SELECT disciplinary.id,residents.surname,residents.name,residents.fatherland,disciplinary.reason,disciplinary.date
        FROM disciplinary,residents
        WHERE residents.id=disciplinary.id_rez'''
    cursor.execute(quary)
    result = cursor.fetchall()
    res = [i for i in result if
           (search in i[1].lower()) or (search in i[2].lower()) or (search in i[3].lower()) or (
                   search in i[4].lower()) or (search.lower() in (i[2]+" "+i[3]+" "+i[4]).lower())]
    connection.commit()
    cursor.close()
    connection.close()
    return res
def reference_search(search):
    connection = data_con()
    cursor = connection.cursor()
    search = search.lower()
    quary = f'''SELECT reference.id,reference.file,residents.surname,residents.name,residents.fatherland,type_reference.name,reference.date
        FROM reference,residents,type_reference 
        WHERE residents.id=reference.id_res AND reference.id_type=type_reference.id'''
    cursor.execute(quary)
    result = cursor.fetchall()
    res = [i for i in result if
           (search in i[2].lower()) or (search in i[3].lower()) or (search in i[4].lower()) or (
                   search.lower() in i[5].lower()) or (search.lower() in (i[2]+" "+i[3]+" "+i[4]).lower())]
    connection.commit()
    cursor.close()
    connection.close()
    return res
print(disciplinary())
print(reference())

print(rooms_selctor())
